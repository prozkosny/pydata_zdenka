


import plotly.express as px

import pandas as pd
from matplotlib import pyplot as plt
from matplotlib import gridspec
# Načtení dat z CSV souboru
url ='https://raw.githubusercontent.com/petrrozkosny/pydata/refs/heads/main/pydata_data.csv'

df = pd.read_csv(url,sep=";")

df["ROK"] = pd.to_datetime(df["DATE"]).dt.year
df["MESIC"] = pd.to_datetime(df["DATE"]).dt.month

'''
1. Roční sumu srážek v RUZYNE (přes 1 řádek a 1 sloupec)
2. Průměrné měsíční srážky v RUZYNE (přes 1 řádek a 1 sloupec)
3. Průměrné měsíční srážky v RUZYNE v 2002 (přes 2 řádky a  1 sloupec)

- každý graf bude mít nadpis
- maximální roční srážky v RUZYNE (graf 1 bude mít barvu red, ostatní cyan)
'''

rocni_srazky_ruzyne = df.loc[df["NAME"]=="RUZYNE"].groupby(by="ROK",as_index=False)["PRCP"].sum()
mesicni_srazky_ruzyne = df.loc[df["NAME"]=="RUZYNE"].groupby(by="MESIC",as_index=False)["PRCP"].mean()

mesicni_srazky_ruzyne_2002 = df.loc[(df["NAME"]=="RUZYNE")&(df["ROK"]==2002)].groupby(by="MESIC",as_index=False)["PRCP"].mean()
max_rocni_srazky_ruzyne = rocni_srazky_ruzyne["PRCP"].max()

fig = px.line(rocni_srazky_ruzyne,x="ROK",y="PRCP")

fig.write_html("graf.html")
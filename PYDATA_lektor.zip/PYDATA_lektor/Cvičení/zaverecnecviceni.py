
import pandas as pd
url ='https://raw.githubusercontent.com/petrrozkosny/pydata/refs/heads/main/pydata_data.csv'



df = pd.read_csv(url,sep=";")
df["DATE"] = pd.to_datetime(df["DATE"])
df = df.assign(ROK=df["DATE"].dt.year,MESIC=df["DATE"].dt.month,DEN=df["DATE"].dt.day)

dates = pd.date_range("2000-01-01","2000-12-31",freq="D")
dates = dates.to_frame()
dates = dates.rename(columns={0:"DATE"})
dates = dates.assign(MESIC=dates["DATE"].dt.month,DEN=dates["DATE"].dt.day)

df_r_2000 = df.loc[(df["NAME"]=="RUZYNE")&(df["ROK"] == 2000)]
df_r_2001 = df.loc[(df["NAME"]=="RUZYNE")&(df["ROK"] == 2001)]

dates = pd.merge(left=dates,right=df_r_2000[["MESIC", "DEN", "PRCP"]],left_on=["MESIC","DEN"],right_on=["MESIC","DEN"])
dates = pd.merge(left=dates,right=df_r_2001[["MESIC", "DEN", "PRCP"]],left_on=["MESIC","DEN"],right_on=["MESIC","DEN"],suffixes=("","_2001"))
dates = dates.rename(columns={"PRCP":"PRCP_2000"})
dates["DATE_STR"] = dates["DATE"].dt.strftime(date_format="%m-%d")
dates["PRCP_2000"] = dates["PRCP_2000"].cumsum()
dates["PRCP_2001"] = dates["PRCP_2001"].cumsum()


df_r_2000_g = df_r_2000.groupby(by="MESIC")["PRCP"].sum()
df_r_2000_mean  = df_r_2000_g.mean()
df_r_2000_max = df_r_2000_g.max()
barvy = ["red" if x == df_r_2000_max else "blue" for x in df_r_2000_g]

df_lokality_2000_mean = df.loc[df["ROK"]==2000].groupby(by="NAME")["PRCP"].mean()
df_lokality_2000_max = df.loc[df["ROK"]==2000].groupby(by="NAME")["PRCP"].max()

from matplotlib import pyplot as plt

fig, ax = plt.subplots(4,1,figsize=(10,7))

ax[0].plot(dates["DATE"],dates["PRCP_2000"],label="2000")
ax[0].plot(dates["DATE"],dates["PRCP_2001"],label="2001")

ax[1].bar(df_r_2000_g.index,df_r_2000_g,color=barvy)
ax[1].plot(df_r_2000_g.index,[df_r_2000_mean]*12,color="red",linestyle=":",alpha=0.5)
ax[2].bar(df_lokality_2000_mean.index,df_lokality_2000_mean)
ax[3].bar(df_lokality_2000_max.index,df_lokality_2000_max)

ax[0].legend()
plt.tight_layout()
# plt.show()

df["TEPLOTY"] = df["TMAX"].astype(str)+" | "+df["TMIN"].astype(str)
print(df.head())


df_ruzyne = df.loc[df["NAME"]=="RUZYNE"]
df_ruzyne_max = df_ruzyne["PRCP"].max()
df_ruzyne_max_datum = df_ruzyne.loc[df_ruzyne["PRCP"]==df_ruzyne_max,"DATE"]
print(df_ruzyne_max_datum)

dfna = df.loc[df["PRCP"].isna()].groupby(by="NAME")["NAME"].count()

df_ruzyne_roky = df.loc[df["NAME"]=="RUZYNE"].groupby(by="ROK")["PRCP"].sum()

df_ruzyne_shift = df_ruzyne_roky.shift(1)
df_rozdil = df_ruzyne_roky - df_ruzyne_shift
df_rozdil_rok = df_rozdil.loc[df_rozdil==df_rozdil.max()]
print(df_rozdil_rok.index)